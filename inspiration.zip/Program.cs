﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;

namespace Alchemy
{
    class MyException : Exception {
        public MyException(string s) : base(s) {

        }
    }

    static class Log {
        public static List<string> log = new List<string>();
        public static void WriteLog(IEnumerable<Item> things, IEnumerable<Item> product)
        {
            var next = " = ";
            string s = product == null? "NIC" : product.Select(i=>i.Name).JoinString(" a ");
            foreach(var i in things)
            {
                s += next + i.Name;
                next = " + ";
            }
            log.Add(s);
        }
    }

    static class RecipeBook
    {
        public static List<Recipe> Book = new List<Recipe>();
        public static void Load(StreamReader InputStream) {
            string s = InputStream.ReadLine().ToLowerInvariant();
            while(s != "" && s!= null)
            {
                string[] x = s.Split(',', '+', '=', ':', ';');
                var mapped = x.Select(i => Item.GetItem(i));
                var recipe = new Recipe(mapped.First(),mapped.Skip(1));
                s = InputStream.ReadLine()?.ToLowerInvariant(); 
            }
        }
        public static IEnumerable<Item> Craft(List<Item> sources)
        {
            IEnumerable<Item> result = null;
            sources.Sort();
            if(Book.Any(r=> r.Items.exact(sources)))
            {
                result= Book.Where(r => r.Items.exact(sources)).Select(i=>i.Target);
                
            } else 
            if(Book.Any(r => sources.Sub(r.Items))) {
                result = new Item[] { Book.Where(r => sources.Sub(r.Items)).ToList().Random().Target };
            }
            Log.WriteLog(sources, result);
            if(result!= null) {
                foreach (var r in result) {
                    r.Count++;
                    r.isKnown = true;
                }
            }
            return result;
            
        }
    }

    class Recipe
    {
        public override string ToString()
        {
            return Target.Name + " = " + Items.Aggregate("", (s, it) => s + (s==""?"": " + ") + it.Name);
        }
        public Item Target { get; }
        public List<Item> Items { get; }
        public Recipe(Item Target, IEnumerable<Item> Items)
        {
            this.Target = Target;
            this.Items = Items.ToList();
            this.Items.Sort();
            RecipeBook.Book.Add(this);
        }
    }

    class Item : IComparable<Item>
    {
        public static Dictionary<string, Item> StringItem = new Dictionary<string, Item>();
        public static Dictionary<int, Item> IntItem = new Dictionary<int, Item>();
        public static List<Item> ItemList = new List<Item>();
        public readonly int ID;
        public readonly string Name;
        public int Count = 0;
        public bool isKnown = false;

        public static void Init(StreamReader InputStream) {
            string s = null;
            s = InputStream.ReadLine().Trim().ToLowerInvariant();
            while (s!= "")
            {
                new Item(s);
                s = InputStream.ReadLine().Trim().ToLowerInvariant();
            }
        }

        private static int count = 0;
        private Item(string Name)
        {
            count++;
            this.Name = Name;
            this.ID = count;
            StringItem.Add(Name, this);
            IntItem.Add(ID, this);
            ItemList.Add(this);
        }

        public int CompareTo(Item other)
        {
            if (other == null)
            {
                throw new ArgumentNullException(nameof(other));
            }
            return this.ID - other.ID;
        }
        public static Item GetItem(string s)
        {
            string s1 = s.Trim();
            if (s1 == "") {
                throw new MyException("Prázdný string není žádný předmět!");
            }
            int pokus = 0;
            if (int.TryParse(s1,out pokus)) {
                if (pokus< ItemList.Count)
                {
                    return ItemList[pokus];
                }
            }

            Item vec = ItemList.WithMin(it => dist(it.Name, s1));
            if (dist(vec.Name, s1) != 0) {
                Program.notice += ('"' + s1 + "\" nebyl nalezen, interpretováno jako " + vec.Name + ". ");
            }

            return vec;
        }
        private static int dist(string s, string s1) {
            int[,] pole = new int[s.Length+1, s1.Length+1];
            for(int i=0; i<=s.Length; i++)
            {
                for(int j=0; j<=s1.Length; j++)
                {
                    int min = int.MaxValue;
                    if (i > 0)
                    {
                        min = Math.Min(min, pole[i - 1, j]+1);
                    }
                    if (j > 0)
                    {
                        min = Math.Min(min, pole[i, j-1]+1);
                    }
                    if(i>0 && j > 0)
                    {
                        min = Math.Min(min, pole[i - 1, j - 1] + (s[i-1]==s1[j-1]?0:1));
                    }
                    if (i == 0 && j == 0) {
                        min = 0;
                    }
                    pole[i, j] = min;
                }
            }
            return pole[s.Length, s1.Length] - (Math.Abs(s.Length - s1.Length)*3/4);
        }
        public override string ToString()
        {
            return ID + " " + Name + " (" + Count.ToString()+")";
        }
    }

    class Program
    {
        static public string notice = "";
        static void Main(string[] args)
        {
            StreamReader s = new StreamReader("recipes.txt");
            Item.Init(s);
            RecipeBook.Load(s);
            s.Close();
            string PrevStatement = "";
	    while (true) {
                Console.Clear();
                Console.WriteLine("Inventář:");
                Console.WriteLine();
                int minwidth = 1;
                try
                {
                    minwidth = Item.ItemList.Where(i => i.isKnown).Select(i => i.Name.Length + i.Count.ToString().Length).Max() + 4;
                } catch { }
                int cols = (Console.WindowWidth / minwidth);
                int width = Console.WindowWidth/cols;
                int counter = 0;
                foreach (Item i in Item.ItemList.Where(i => i.isKnown)) {
                    counter++;
                    Console.Write((i.Name + " (" + i.Count.ToString() + ") ").PadRight(width));
                    if(counter % cols == 0) {
                        Console.WriteLine();
                    }

                }
                if (counter % cols != 0) { Console.WriteLine(); }
                Console.WriteLine();
                Console.WriteLine(PrevStatement);
                PrevStatement = "";
                if (notice != "") {
                    Console.WriteLine();
                    Console.WriteLine(notice);
                    notice = "";

                }
                Console.WriteLine();
                Console.WriteLine("Můžeš provést (V)ýrobu, (M)ultivýrobu, prohlédnout si (H)istorii, ohlásit příbytek nebo úbytek (S)urovin nebo si říct o (P)omoc.");
                string Input = Console.ReadLine().ToLowerInvariant();
                if(Input==null || Input == "") {
                    continue;
                }
                try {
                    int pocet = 1;
                    switch (Input[0]) {
                    case 'v':
                        Console.WriteLine("Z čeho chcete vyrábět? Očekávám seznam oddělený čárkami.");
                        string sources_string = Console.ReadLine();
                        if(sources_string == "") {throw new MyException("Nezadali jste žádné předměty.");}
                        var sources = sources_string.Split(new char[] { ',', '.',':'}, StringSplitOptions.RemoveEmptyEntries).Select(i=>i.Trim().ToLowerInvariant()).Where(i=>i!= "").Select(Item.GetItem).ToList();
                        //if(sources==null) {
                            
                        //}
                        sources.Sort();
                        PrevStatement = Multicraft(pocet, sources);
                        break;
                    case 'm':
                        Console.WriteLine("Kolikrát chcete vyrábět?");
                        string c = Console.ReadLine().Trim();
                        if(!int.TryParse(c,out pocet) || pocet < 0|| pocet > 10000) {
                            throw new MyException(c + " není číslo, není kladné, nebo je větší než 10000.");
                        }
                        goto case 'v';
                        break;
                    case 'h':
                        History();
                        break;
                    case 'p':
                        Pomoc();
                        break;
                    case 's':
                        Console.WriteLine("Kolik se má přidat/ubrat (záporné číslo pro ubírání).");
                        string g = Console.ReadLine().Trim();
                        if (!int.TryParse(g, out pocet) || pocet == 0 || pocet > 10000 || pocet < -10000) {
                            throw new MyException(g + " není číslo, není mezi -10000 a 10000, nebo je to nula.");
                        }
                        Console.WriteLine("Kterého předmětu se má přidat nebo ubrat?");
                        Item it = Item.GetItem(Console.ReadLine().ToLowerInvariant());
                        if(it.Count + pocet < 0) {
                            throw new MyException("Předmětu \"" + it.Name + "\" máte jen " + it.Count.ToString() + ", nemůžete " + (-pocet).ToString() + " ubrat!");
                        }
                        it.Count += pocet;
                        it.isKnown = true;
                        break;

                    }
                } catch (MyException e) {
                    PrevStatement = e.Message;
                }
            }
        }

        static void History() {
            int increments = Console.WindowHeight - 4;
            int start = increments;
            char command = 'p';
            while (command != 'o') {
                if(command == 'p') {
                    start = Math.Max(start - increments, 0);
                }
                if (command == 'd') {
                    if(start + increments < Log.log.Count+5) {
                        start += increments;
                    }
                }
                display(Log.log, increments, start);
                Console.WriteLine();
                Console.WriteLine("(D)alší, (P)ředchozí, (O)dejít?");
                string s = Console.ReadLine();
                if (s.Length == 0) { command = 'x'; continue; }
                command = s.ToLower()[0];
            }
            
        }
        static string Multicraft (int counts,List<Item> from)
        {
            Item last = null;
            int count = 0;
            foreach(Item i in from) {
                if(last == null) {
                    last = i;
                }
                if (last == i) {
                    count++;
                } else {
                    if(last.Count < count * counts) {
                        throw new MyException("Chyba, předmětu \"" + last.Name + "\" máte jen " + last.Count.ToString() + ", ale potřebovali byste alespoň " + (count * counts).ToString() + ".");
                    }
                    count = 1;
                    last = i;
                }
            }
            if (last.Count < count * counts) {
                throw new MyException("Chyba, předmětu \"" + last.Name + "\" máte jen " + last.Count.ToString() + ", ale potřebovali byste alespoň " + (count * counts).ToString() + ".");
            }
            last = null;
            count = 0;
            foreach (Item i in from) {
                if (last == null) {
                    last = i;
                }
                if (last == i) {
                    count++;
                } else {
                    last.Count -= count * counts;
                    count = 1;
                    last = i;
                }
            }
            last.Count -= count * counts;
            
            var res = new List<Item>();
            for (int i = 0; i<counts; i++) {
                var results = RecipeBook.Craft(from);
                if (results != null) {
                    foreach (var r in results)
                        res.Add(r);
                } else res.Add(null);
            }
            return "Vyrobeno: " + res.Aggregate("", (j, k) => j + (k==null?"nic":k.Name) + ", ");

        }
        static void Pomoc()
        {
            var s = new StreamReader("pomoc.txt");
            Console.Clear();
            Console.WriteLine(s.ReadToEnd());
            Console.ReadLine();
        }
        static void display(List<string> source, int lines, int from) {
            Console.Clear();
            for (int i = from; i<from+lines; i++) {
                if (i < source.Count) {
                    Console.WriteLine(source[i]);
                }
            }
        }
    }
    
    public static class E
    {
        public static T WithMin<T>(this IEnumerable<T> source, Func<T,int> selector) {
            T vec = default(T);
            int min = int.MaxValue;
            foreach(T thing in source)
            {
                if (selector(thing) < min)
                {
                    min = selector(thing);
                    vec = thing;
                }
            }
            return vec;
        }

        /// <summary>
        /// Says whether the argument is substring of the other. Doesn't work with value types.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="first"></param>
        /// <param name="other"></param>
        /// <returns></returns>
        public static bool Sub<T>(this IEnumerable<T>first, IEnumerable<T> other)
        {
            var ot = other.GetEnumerator();
            if (!ot.MoveNext())
            {
                return true;
            }
            foreach(T thing in first)
            {
                if (object.ReferenceEquals(thing, ot.Current))
                {
                    if (!ot.MoveNext())
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        public static bool exact<T>(this List<T> first, List<T> other)
        {
            
            if(first.Count != other.Count){
                return false;
            }
            for(int i=0; i<first.Count; i++)
            {
                if (!object.ReferenceEquals(first[i], other[i])) {
                    return false;
                } 
            }
            return true;
        }

        public static string JoinString(this IEnumerable<string> input, string sep) {
            string s = "";
            string r = "";
            foreach(string i in input) {
                r += s + i;
                s = sep;
            }
            return r;
        }

        private static Random random = new Random();
        public static T Random<T>(this List<T> source) {
            return source[random.Next(source.Count)];
        }
    }
}
